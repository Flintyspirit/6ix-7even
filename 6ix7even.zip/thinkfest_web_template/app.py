from flask import Flask, request, jsonify, send_from_directory, send_file
from flask_mysqldb import MySQL
from flask_cors import CORS
import smtplib
from email.mime.text import MIMEText
import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from io import BytesIO

app = Flask(__name__)
CORS(app)

# --------------------------
# CONFIG
# --------------------------
FRONTEND_FOLDER = os.path.join(os.getcwd(), "frontend")
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root'
app.config['MYSQL_DB'] = 'Management'

mysql = MySQL(app)

# --------------------------
# EMAIL NOTIFICATION
# --------------------------
def send_notification(user_email, issue, status):
    sender_email = "kushsingha1718@gmail.com"
    app_password = "your_16_char_app_password_here"  # Use Gmail App Password

    subject = "6ix 7even Service Request Update"
    message = f"""
Hello,

Your service request has been updated.

Issue: {issue}
New Status: {status}

Thank you,
6ix 7even Support Team
"""
    msg = MIMEText(message)
    msg["Subject"] = subject
    msg["From"] = sender_email
    msg["To"] = user_email

    try:
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.ehlo()
            server.starttls()
            server.login(sender_email, app_password)
            server.send_message(msg)
        print(f"[SUCCESS] Email sent to {user_email}")
    except Exception as e:
        print(f"[ERROR] Email failed: {e}")

# --------------------------
# SERVE FRONTEND
# --------------------------
@app.route("/")
def login_page():
    return send_from_directory(FRONTEND_FOLDER, "login.html")

@app.route("/<path:path>")
def static_files(path):
    return send_from_directory(FRONTEND_FOLDER, path)

@app.route("/dashboard")
def dashboard_page():
    return send_from_directory(FRONTEND_FOLDER, "dashboard.html")

# --------------------------
# LOGIN
# --------------------------
@app.route("/login", methods=["POST"])
def login():
    data = request.json
    email = data.get("email")
    password = data.get("password")

    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM users WHERE email=%s AND password=%s", (email, password))
    user = cur.fetchone()
    cur.close()

    if user:
        return jsonify({"success": True, "user_name": user[1], "role": user[4], "user_id": user[0]})
    return jsonify({"success": False})

# --------------------------
# REGISTER
# --------------------------
@app.route("/register", methods=["POST"])
def register():
    data = request.json
    name = data.get("user_name")
    email = data.get("email")
    password = data.get("password")
    role = "user"

    cur = mysql.connection.cursor()
    cur.execute("INSERT INTO users (user_name,email,password,role) VALUES (%s,%s,%s,%s)",
                (name, email, password, role))
    mysql.connection.commit()
    cur.close()
    return jsonify({"message": "Registration Successful"})

# --------------------------
# SUBMIT REPORT
# --------------------------
@app.route("/submit_report", methods=["POST"])
def submit_report():
    data = request.json
    user_name = data.get("user_name")
    report_type = data.get("report_type")

    cur = mysql.connection.cursor()
    # Get user email from users table
    cur.execute("SELECT email FROM users WHERE user_name=%s", (user_name,))
    result = cur.fetchone()
    contact_email = result[0] if result else "Not provided"

    # Insert report
    cur.execute("INSERT INTO service_reports (user_name, report_type, contact) VALUES (%s,%s,%s)",
                (user_name, report_type, contact_email))
    mysql.connection.commit()
    cur.close()
    return jsonify({"message": "Report submitted successfully"})

# --------------------------
# GET REPORTS
# --------------------------
@app.route("/get_reports", methods=["GET"])
def get_reports():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM service_reports ORDER BY track_id DESC")
    rows = cur.fetchall()
    cur.close()

    report_list = []
    for r in rows:
        report_list.append({
            "track_id": r[0],
            "user_name": r[1],
            "report_type": r[2],
            "contact": r[3],
            "date_time": str(r[4]),
            "status": r[5] if r[5] else "Pending"
        })
    return jsonify(report_list)

# --------------------------
# UPDATE REPORT STATUS (SEND EMAIL TO contact)
# --------------------------
@app.route("/update_report/<int:track_id>", methods=["PUT"])
def update_report(track_id):
    data = request.json
    new_status = data.get("status", "Pending")

    cur = mysql.connection.cursor()
    cur.execute("SELECT user_name, report_type, contact FROM service_reports WHERE track_id=%s", (track_id,))
    report = cur.fetchone()
    if not report:
        cur.close()
        return jsonify({"message": "Report not found"}), 404

    user_name = report[0]
    issue = report[1]
    contact_email = report[2]

    # Update status
    cur.execute("UPDATE service_reports SET status=%s WHERE track_id=%s", (new_status, track_id))
    mysql.connection.commit()
    cur.close()

    # Send notification to email in service_reports
    if contact_email and contact_email != "Not provided":
        send_notification(contact_email, issue, new_status)

    return jsonify({"message": f"Report {track_id} status updated to {new_status} and notification sent"})

# --------------------------
# DELETE REPORT
# --------------------------
@app.route("/delete_report/<int:track_id>", methods=["DELETE"])
def delete_report(track_id):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM service_reports WHERE track_id=%s", (track_id,))
    mysql.connection.commit()
    cur.close()
    return jsonify({"message": f"Report {track_id} deleted successfully"})

# --------------------------
# DASHBOARD COUNTS
# --------------------------
@app.route("/total_users", methods=["GET"])
def total_users():
    cur = mysql.connection.cursor()
    cur.execute("SELECT COUNT(*) FROM users")
    total = cur.fetchone()[0]
    cur.close()
    return jsonify({"total_users": total})

@app.route("/total_reports", methods=["GET"])
def total_reports():
    cur = mysql.connection.cursor()
    cur.execute("SELECT COUNT(*) FROM service_reports")
    total = cur.fetchone()[0]
    cur.close()
    return jsonify({"total_reports": total})

# --------------------------
# CHARTS
# --------------------------
@app.route("/status_chart")
def status_chart():
    cur = mysql.connection.cursor()
    cur.execute("SELECT status, COUNT(*) FROM service_reports GROUP BY status")
    data = cur.fetchall()
    cur.close()

    labels, values = [], []
    for row in data:
        labels.append(row[0])
        values.append(row[1])

    plt.figure(figsize=(6,6))
    plt.pie(values, labels=labels, autopct='%1.1f%%')
    plt.title("Service Request Status Distribution")

    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    return send_file(img, mimetype='image/png')

@app.route("/type_chart")
def type_chart():
    cur = mysql.connection.cursor()
    cur.execute("SELECT report_type, COUNT(*) FROM service_reports GROUP BY report_type")
    data = cur.fetchall()
    cur.close()

    labels, values = [], []
    for row in data:
        labels.append(row[0])
        values.append(row[1])

    plt.figure(figsize=(8,5))
    plt.bar(labels, values)
    plt.xlabel("Report Type")
    plt.ylabel("Number of Reports")
    plt.title("Reports by Type")

    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    return send_file(img, mimetype='image/png')

# --------------------------
# RUN SERVER
# --------------------------
if __name__ == "__main__":
    app.run(debug=True)